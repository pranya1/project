package com.cg.springmoviesangular.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmoviesangular.bean.Movie;

@Repository
public class MovieDAOImpl implements IMovieDAO {

	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public List<Movie> getAllMovies() {
		Query queryOne = entitymanager.createQuery("select m FROM Movie m");
		List<Movie> allMovies = queryOne.getResultList();
		return allMovies;
	}

	@Override
	public void addMovie(Movie movie) {
		entitymanager.persist(movie);
		entitymanager.flush();

	}

	@Override
	public List<Movie> getAllGenreMovies() {
		// TODO Auto-generated method stub
		return null;
	}

}
