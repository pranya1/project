package com.cg.springmoviesangular.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.springmoviesangular.bean.Movie;
import com.cg.springmoviesangular.dao.IMovieDAO;

@Service
@Transactional
public class MovieServiceImpl implements IMovieService {

	@Autowired
	IMovieDAO moviedao;

	@Override
	public List<Movie> getAllMovies() {
		return moviedao.getAllMovies();
	}

	@Override
	public void addMovie(Movie movie) {
		moviedao.addMovie(movie);

	}

	@Override
	public List<Movie> getAllGenreMovies() {
		// TODO Auto-generated method stub
		return null;
	}

}
