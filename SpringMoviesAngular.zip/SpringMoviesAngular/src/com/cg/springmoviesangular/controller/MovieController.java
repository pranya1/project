package com.cg.springmoviesangular.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.springmoviesangular.bean.Movie;
import com.cg.springmoviesangular.service.IMovieService;

@RestController
@RequestMapping("/test")
public class MovieController {

	@Autowired
	IMovieService movieservice;
	
	
	@RequestMapping(value = "/movies",method = RequestMethod.GET,headers="Accept=application/json",produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Movie> getAllMovies(Model model) {
		return movieservice.getAllMovies();
		
	}
	
	
	@RequestMapping(value ="/movie/create/",consumes = MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",method = RequestMethod.POST)
	public List<Movie> createMovie(@RequestBody Movie movie) {
		System.out.println(movie);
		movieservice.addMovie(movie);
		return movieservice.getAllMovies();
}
}
