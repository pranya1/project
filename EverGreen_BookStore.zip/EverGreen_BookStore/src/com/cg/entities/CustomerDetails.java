package com.cg.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class CustomerDetails {
	@Id
	@GeneratedValue
	private int customerId;
	private String fullName;
	//unique
	private String email;
	private String city;
	private String country;
	private String registeredDate;
	private String password;
	private long phoneNumber;
	private String address;
	private String zipCode;
}
