package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.Book;
import com.cg.model.Category;

import com.cg.service.IBookService;
import com.cg.service.ICategoryService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class BookController {

	@Autowired
	IBookService iBookService;
	@Autowired
	ICategoryService iCategoryService;


	

	@PostMapping("/add_Category")
	public Category add_Category(@RequestBody Category category) {
		iCategoryService.save(category);
		return category;
	}

	@RequestMapping("/searchByCategory/{category}")
	public List<Book> searchByCategory(@PathVariable("category") String category) {
		Category category1 = iCategoryService.findByCategory(category);
		List<Book> list = iBookService.findByCategory(category1);
		System.out.println(list);
		return list;
	}
	@RequestMapping("/listOfAllBooks")
	public List<Book> listOfAllBooks()
	{
		return iBookService.findAll();
	}
	

	

	
	

	

	/*@RequestMapping("/editCategory")
	public Category editCategory(@RequestParam("categoryId") int categoryId, Model model) {
		Category category = iCategoryService.findByCategoryId(categoryId);
		model.addAttribute("command", category);
		return category;
	}*/

	/*@PostMapping("/updateCategory")
	public Category updateCategory(@ModelAttribute("category") Category category) {
		iCategoryService.save(category);
		return category;
	}*/

	/*@RequestMapping("/deleteCategory")
	public String deleteCategory(@RequestParam("categoryId") int categoryId) {
		Category category = iCategoryService.findByCategoryId(categoryId);
		Category category1 = iCategoryService.findByCategory("NA");
		List<Book> booksOfCategory = iBookService.findByCategory(category);
		for (Book book : booksOfCategory) {
			book.setCategory(category1);
			iBookService.save(book);
		}
		iCategoryService.remove(category);
		return "Deleted Succesfully";
	}*/

}
