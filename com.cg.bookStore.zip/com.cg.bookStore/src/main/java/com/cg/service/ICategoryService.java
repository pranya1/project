package com.cg.service;

import com.cg.model.Category;

public interface ICategoryService {

	public Category save(Category category);

	public Category findByCategory(String categoryName);

	public Category findByCategoryId(int categoryId);

	public void remove(Category category);

}
