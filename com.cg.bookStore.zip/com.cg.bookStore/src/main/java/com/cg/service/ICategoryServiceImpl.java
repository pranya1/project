package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ICategoryDao;
import com.cg.model.Category;

@Service("iCategoryService")
public class ICategoryServiceImpl implements ICategoryService {

	@Autowired
	ICategoryDao iCategoryDao;

	public Category save(Category category) {
		return iCategoryDao.save(category);
	}

	@Override
	public Category findByCategory(String categoryName) {
		// TODO Auto-generated method stub
		return iCategoryDao.findCategory(categoryName);
	}

	@Override
	public Category findByCategoryId(int categoryId) {
		Category category = iCategoryDao.findCategoryById(categoryId);
		if (category != null) {
			return category;
		} else {
			return category;
		}
	}

	@Override
	public void remove(Category category) {
		// TODO Auto-generated method stub
		iCategoryDao.delete(category);
	}

}
