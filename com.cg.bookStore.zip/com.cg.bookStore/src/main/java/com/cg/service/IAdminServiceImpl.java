package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IAdminDao;
import com.cg.model.Admin;

@Service("iAdminService")
public class IAdminServiceImpl implements IAdminService {

	@Autowired
	IAdminDao iAdminDao;

	@Override
	public Admin findByEmail(String email) {

		Admin admin = iAdminDao.findByEmail(email);
		if (admin != null) {
			return admin;
		} else {
			return admin;
		}
	}

	public Admin save(Admin admin) {
		return iAdminDao.save(admin);
	}

}
