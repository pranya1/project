package com.cg.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.entities.Coupons;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.ReturnedItems;
import com.cg.entities.SoldItems;

public interface ICapStoreService {

	boolean add(int customerId,int inventoryId);

	public void remove(int inventoryId,int customerId);

	void tableCreation();

	public List<Inventory> fetchCart(int customerId);

	boolean checkAvailability(int customerId);

	public int totalAmount(int customerId);

	public int totalDiscount(int customerId);

	List<String> getCoupons(int customerId);

	Double getCouponDiscount(String couponId);

	Customer getCustomer(int customerId);

	void updateMoney(List<Inventory> list);

	void addSoldItems(int customerId, int inventoryId);

	void deleteCoupon(String couponId); 

	//manoj

	public abstract List<SoldItems> getBusinessByProducts(String inventoryName,LocalDate fromDate,LocalDate toDate);
	public abstract List<SoldItems> getBusinessByProductCatagory(String inventoryType,LocalDate fromDate,LocalDate toDate);
	public abstract List<SoldItems> getBusinessByProductsAndMerchant(String inventoryType,String merchantName,LocalDate fromDate,LocalDate toDate);

	void returnItems(Integer soldItemId, LocalDate now);

	List<ReturnedItems> loadReturnedItems();

	boolean updateInventoryByAdmin(Integer soldItemId, LocalDate now);

	void refundMoney(Integer soldItemId);


	


}
