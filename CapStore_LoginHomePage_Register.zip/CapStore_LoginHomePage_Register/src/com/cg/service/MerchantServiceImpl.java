package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IMerchantDAO;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;
import com.cg.entities.SoldItems;


@Service
@Transactional
public class MerchantServiceImpl implements IMerchantService{
	
	@Autowired
	IMerchantDAO iMerchantDAO;
	
	@Override
	public Merchant isMerchant(String userName, String userPassword) {
		// TODO Auto-generated method stub
		return iMerchantDAO.isMerchant(userName,userPassword);
	}

	@Override
	public String getMerchantPassword(String userName) {
		// TODO Auto-generated method stub
		return iMerchantDAO.getMerchantPassword(userName);
	}
	@Override
	public void plp() {
		iMerchantDAO.plp();
	}



	@Override
	public void viewInventory() {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void addProducts() {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void removeProduct() {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void addDiscount() {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void removeDiscount() {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void checkOrders() {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void promos() {
		// TODO Auto-generated method stub
		
	}



	@Override
	public Merchant showDetails(int id) {
	
		return iMerchantDAO.showDetails(id);
	}



	@Override
	public List<Inventory> loadAll(int id) {
		// TODO Auto-generated method stub
		return iMerchantDAO.loadAll(id);
	}



	@Override
	public boolean removeInventory(int inventory) {
		// TODO Auto-generated method stub
		return iMerchantDAO.removeInventory(inventory);
	}



	@Override
	public Inventory findInventory(int inventoryId) {
		// TODO Auto-generated method stub
		return iMerchantDAO.findinventory(inventoryId);
	}



	@Override
	public Inventory addinventory(Inventory inventories) {
		// TODO Auto-generated method stub
		return iMerchantDAO.addinventory(inventories);
	}



	@Override
	public Merchant findMerchant(int merchantId) {
		
		return iMerchantDAO.findMerchant(merchantId);
	}



	@Override
	public void updateInventory(Inventory inventory) {
		
		iMerchantDAO.updateInventory(inventory);
	}



	@Override
	public void updateInventoryImage(Inventory inventory) {
		
		iMerchantDAO.updateInventoryImage(inventory);
	}

	@Override
	public List<Inventory> getAllInventory() {
		// TODO Auto-generated method stub
		return iMerchantDAO.getAllInventory();
	}

	@Override
	public List<SoldItems> getAllInventoryOfMerchant(int merchantId) {
		// TODO Auto-generated method stub
		return iMerchantDAO.getAllInventoryOfMerchant(merchantId);
	}

	@Override
	public void updateStatus(int merchantId, SoldItems soldItems, String string) {
		// TODO Auto-generated method stub
		iMerchantDAO.updateStatus(merchantId,soldItems,string);
	}

	@Override
	public void setRating(String rate, String soldId) {
		// TODO Auto-generated method stub
		iMerchantDAO.setRating(rate,soldId);
	}


}
